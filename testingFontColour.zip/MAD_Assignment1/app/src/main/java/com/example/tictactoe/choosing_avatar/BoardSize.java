package com.example.tictactoe.choosing_avatar;

public enum BoardSize {
    ThreeXThree, FourXFour, FiveXFive;
}
