package com.example.tictactoe.choosing_avatar;

import com.example.tictactoe.choosing_avatar.Avatar;

public interface SelectListener {
        void onItemClicked(Avatar avatar);

}
