package com.example.tictactoe.gameplay;

public class TurnHistory {
    int x;
    int y;

    public TurnHistory(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
